/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./src/injectAXS_feedbackImage.js ***!
  \****************************************/


// Content script file will run in the context of web page.
// With content script you can manipulate the web pages using
// Document Object Model (DOM).
// You can also pass information to the parent extension.

// We execute this script by making an entry in manifest.json file
// under `content_scripts` property

// For more information on Content Scripts,
// See https://developer.chrome.com/extensions/content_scripts

console.log('injectAXS_feedbackImage - Injected');

function injectFeedbackIframe() {
  console.log('*************injectFeedbackIframe()*************');
  let mainContainer = document.querySelector(".event-summary-headline") //append as second child
  //Create Iframe
  //container for iframe
  var iframeContainer = document.createElement('div');
  iframeContainer.classList.add('feedback-status-container');
  iframeContainer.style.position = 'inherit';
  iframeContainer.style.display = 'flex';
  iframeContainer.style.alignItems = 'center';
  iframeContainer.style.zIndex = 10;
  iframeContainer.style.width = '100%';
  iframeContainer.style.paddingTop = '9px';
  iframeContainer.style.paddingBottom = '24px';
  iframeContainer.style.flexFlow = 'column';
  iframeContainer.style.pointerEvents = 'none';

  var feedback_title = document.createElement('h3');
  feedback_title.innerText = "Waiting for Feedback..."
  feedback_title.classList.add('feedback-title');

  var feedbackImage = document.createElement('img');
  feedbackImage.classList.add('feedback-image');
  feedbackImage.style.width = '200px';
  feedbackImage.style.height = '200px';
  feedbackImage.src = chrome.runtime.getURL("icons/waiting.png");
  iframeContainer.appendChild(feedback_title);
  iframeContainer.appendChild(feedbackImage);
  setTimeout(() => {
    console.log('Inside timeout, appending feedback image now');
    mainContainer.appendChild(iframeContainer);
  }, 200);
}
if (!document.querySelector(".feedback-status-container")) {
  injectFeedbackIframe();
}
/******/ })()
;
//# sourceMappingURL=injectAXS_feedbackImage.js.map