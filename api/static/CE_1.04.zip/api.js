/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/constants.js":
/*!**************************!*\
  !*** ./src/constants.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "API_ENDPOINTS": () => (/* binding */ API_ENDPOINTS),
/* harmony export */   "LS": () => (/* binding */ LS),
/* harmony export */   "domain": () => (/* binding */ domain),
/* harmony export */   "notifications": () => (/* binding */ notifications),
/* harmony export */   "notify": () => (/* binding */ notify),
/* harmony export */   "null_field": () => (/* binding */ null_field),
/* harmony export */   "optionPageURL": () => (/* binding */ optionPageURL),
/* harmony export */   "wsURL": () => (/* binding */ wsURL)
/* harmony export */ });
// export const domain = 'http://127.0.0.1:8000/';
// export const wsURL = 'ws://127.0.0.1:8000';
//Production environment
const domain = 'https://king-prawn-app-j8cb8.ondigitalocean.app/ticket-relay-server2/';
const wsURL = 'wss://king-prawn-app-j8cb8.ondigitalocean.app/ticket-relay-server2';

const null_field = "N/A"

const LS = {
  getAllItems: () => chrome.storage.local.get(),
  getItem: async (key) => (await chrome.storage.local.get(key))[key],
  setItem: (key, val) => chrome.storage.local.set({ [key]: val }),
  removeItems: (keys) => chrome.storage.local.remove(keys),
};
let CE_id = async () => await LS.getItem('CE_id')
const optionPageURL = async () => 'chrome-extension://' + chrome.runtime.id + '/html/options.html';

const API_ENDPOINTS = {
  post_ticket_info: domain + 'api/users/addNewTicket',
  add_Worker_Feedback: domain + 'api/users/addWorkerFeedback',
};

function notify(title, message, iconUrl) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: iconUrl,
    title: title,
    message: message,
    priority: 1,
  });
}

var notifications = {
  ticketInfoSent: function () {
    let title = 'Ticket Details Sent to Managers';
    let message = 'Wait to receive their decision...';
    let iconUrl = '../icons/icon_128.png';
    notify(title, message, iconUrl);
  },
  purchase_confirmation_sent: function () {
    let title = 'Purchase Confirmation Sent to Manager!';
    let message = 'Confirmation Successfully Sent';
    let iconUrl = '../icons/icon_128.png';
    notify(title, message, iconUrl);
  },
  cancel_confirmation_sent: function () {
    let title = 'Ticket Cancellation Sent to Manager!';
    let message = 'Ticket Cancellation Sent';
    let iconUrl = '../icons/icon_128.png';
    notify(title, message, iconUrl);
  },
  new_manager_approval: function (event_name) {
    let title = 'Manager Approved Purchase';
    let message = event_name;
    let iconUrl = '../icons/approved.png';
    notify(title, message, iconUrl);
  },
  new_manager_rejection: function (event_name) {
    let title = 'Manager Rejected Purchase';
    let message = event_name;
    let iconUrl = '../icons/rejected.png';
    notify(title, message, iconUrl);
  },
  new_manager_note: function (event_name) {
    let title = 'Manager Left a Note';
    let message = event_name;
    let iconUrl = '../icons/note.png';
    notify(title, message, iconUrl);
  },
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!********************!*\
  !*** ./src/api.js ***!
  \********************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "API": () => (/* binding */ API)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants.js */ "./src/constants.js");


var API = {
  sendTicketInfo: function (data) {
    return new Promise((resolve, reject) => {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', _constants_js__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.post_ticket_info);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.setRequestHeader('Content-Type', 'application/json');

        xhr.onreadystatechange = async function () {
        if (xhr.readyState === 4) {
            console.log(xhr.response);
            console.log(xhr.status);
            var jsonResponse = JSON.parse(xhr.response);
            var first_digit_response_status_number = String(xhr.status).charAt(0);
            if (first_digit_response_status_number == '4' || jsonResponse.code == 400) {
            console.log('INSIDE ERROR');
            resolve(false)
            } else {
            console.log('Ticket Submitted Successfully');
            resolve(true)
            console.log(jsonResponse);
            }
        }
        };

        xhr.send(JSON.stringify(data));
    });
  },
  add_Worker_Feedback: function (data) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', _constants_js__WEBPACK_IMPORTED_MODULE_0__.API_ENDPOINTS.add_Worker_Feedback);
      xhr.setRequestHeader('Accept', 'application/json');
      xhr.setRequestHeader('Content-Type', 'application/json');

      xhr.onreadystatechange = async function () {
        if (xhr.readyState === 4) {
          console.log(xhr.response);
          console.log(xhr.status);
          var first_digit_response_status_number = String(xhr.status).charAt(0);
          if (first_digit_response_status_number == '4') {
            console.log('INSIDE ERROR');
            console.log(xhr.response);
            var obj = JSON.parse(xhr.response);
            alert(xhr.responseText);
          } else {
            if (data.worker_action_status == 'P') {
                _constants_js__WEBPACK_IMPORTED_MODULE_0__.notifications.purchase_confirmation_sent()
            }
            else {
                _constants_js__WEBPACK_IMPORTED_MODULE_0__.notifications.cancel_confirmation_sent()
            }
            var jsonResponse = JSON.parse(xhr.response);
            console.log(jsonResponse);
          }
          resolve();
        }
      };

      xhr.send(JSON.stringify(data));
    });
  },
};

})();

/******/ })()
;
//# sourceMappingURL=api.js.map